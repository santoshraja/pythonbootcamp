
x = [12, 22, 33, 44, 55]
y = [88, 99, 66, 77, 99]
z = (88 + 99 + 66 + 77 + 99) / len(y)
for i in range(len(x)):
    print(x[i], y[i])
print(z)
