# Clear Code
roll_no = [12, 22, 33, 44, 55]
marks = [88, 99, 66, 77, 99]
mean_marks = (88 + 99 + 66 + 77 + 99) / len(marks)
for i in range(len(roll_no)):
    print(roll_no[i], marks[i])
print(mean_marks)